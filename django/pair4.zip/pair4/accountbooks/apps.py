from django.apps import AppConfig


class AccountbooksConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'accountbooks'
