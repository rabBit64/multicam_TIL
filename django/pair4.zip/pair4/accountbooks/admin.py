from django.contrib import admin
from .models import AccountBook
# Register your models here.

admin.site.register(AccountBook)